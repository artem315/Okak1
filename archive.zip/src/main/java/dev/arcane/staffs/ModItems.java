package dev.arcane.staffs;

import dev.arcane.staffs.item.BlinkStaffItem;
import dev.arcane.staffs.item.ThunderStaffItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import java.util.function.Function;

public final class ModItems {
    public static final Item BLINK_STAFF = register("blink_staff", BlinkStaffItem::new,
            new Item.Properties().durability(250).rarity(Rarity.RARE));

    public static final Item THUNDER_STAFF = register("thunder_staff", ThunderStaffItem::new,
            new Item.Properties().durability(120).rarity(Rarity.EPIC));

    private ModItems() {}

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(ArcaneStaffs.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(BLINK_STAFF);
            entries.accept(THUNDER_STAFF);
        });
    }
}
