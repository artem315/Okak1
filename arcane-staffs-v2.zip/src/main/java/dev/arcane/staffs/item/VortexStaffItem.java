package dev.arcane.staffs.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** ПКМ: вихрь затягивает всех монстров в радиусе 16 блоков в точку перед тобой. */
public class VortexStaffItem extends Item {
    private static final double RADIUS = 16.0;
    private static final double PULL_SPEED = 1.4;

    public VortexStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = player.getItemInHand(hand);
        Vec3 target = player.getEyePosition().add(player.getLookAngle().scale(3.0));

        List<Monster> mobs = serverLevel.getEntitiesOfClass(
                Monster.class, player.getBoundingBox().inflate(RADIUS), Monster::isAlive);
        if (mobs.isEmpty()) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0f, 1.0f);
            return InteractionResult.FAIL;
        }

        for (Monster mob : mobs) {
            Vec3 pull = target.subtract(mob.position()).normalize().scale(PULL_SPEED).add(0, 0.25, 0);
            mob.setDeltaMovement(pull);
            serverLevel.sendParticles(ParticleTypes.PORTAL,
                    mob.getX(), mob.getY() + 1.0, mob.getZ(), 15, 0.3, 0.5, 0.3, 0.3);
        }
        serverLevel.sendParticles(ParticleTypes.PORTAL, target.x, target.y, target.z, 60, 0.6, 0.6, 0.6, 0.5);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1.0f, 0.8f);

        stack.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return InteractionResult.SUCCESS;
    }
}
