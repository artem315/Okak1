package dev.arcane.staffs.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** ПКМ: огненный луч. Поджигает всех в радиусе 5 блоков от точки попадания и ставит огонь на блок. */
public class FireStaffItem extends Item {
    private static final double RANGE = 32.0;
    private static final double BLAST_RADIUS = 5.0;
    private static final float BURN_SECONDS = 8.0f;

    public FireStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = player.getItemInHand(hand);
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(RANGE));

        BlockHitResult hit = level.clip(new ClipContext(
                eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 impact = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();

        // Огненный след от посоха до цели
        int steps = (int) eye.distanceTo(impact);
        for (int i = 1; i < steps; i++) {
            Vec3 p = eye.add(look.scale(i));
            serverLevel.sendParticles(ParticleTypes.FLAME, p.x, p.y - 0.2, p.z, 2, 0.05, 0.05, 0.05, 0.01);
        }
        serverLevel.sendParticles(ParticleTypes.LAVA, impact.x, impact.y, impact.z, 25, 0.8, 0.5, 0.8, 0.1);
        serverLevel.sendParticles(ParticleTypes.SMOKE, impact.x, impact.y, impact.z, 20, 0.8, 0.5, 0.8, 0.05);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0f, 1.0f);

        // Поджигаем всех вокруг точки попадания, кроме самого игрока
        AABB area = new AABB(impact.x - BLAST_RADIUS, impact.y - BLAST_RADIUS, impact.z - BLAST_RADIUS,
                impact.x + BLAST_RADIUS, impact.y + BLAST_RADIUS, impact.z + BLAST_RADIUS);
        for (LivingEntity target : serverLevel.getEntitiesOfClass(LivingEntity.class, area,
                t -> t != player && t.isAlive())) {
            target.igniteForSeconds(BURN_SECONDS);
        }

        // Огонь на блоке
        if (hit.getType() != HitResult.Type.MISS) {
            BlockPos firePos = hit.getBlockPos().relative(hit.getDirection());
            if (level.getBlockState(firePos).isAir()) {
                level.setBlockAndUpdate(firePos, Blocks.FIRE.defaultBlockState());
            }
        }

        stack.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return InteractionResult.SUCCESS;
    }
}
