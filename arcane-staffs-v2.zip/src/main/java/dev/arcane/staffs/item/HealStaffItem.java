package dev.arcane.staffs.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/** ПКМ: лечит тебя и всех игроков в радиусе 8 блоков на 8 HP (4 сердца). */
public class HealStaffItem extends Item {
    private static final double RADIUS = 8.0;
    private static final float HEAL_AMOUNT = 8.0f;

    public HealStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = player.getItemInHand(hand);
        AABB area = player.getBoundingBox().inflate(RADIUS);
        for (Player target : serverLevel.getEntitiesOfClass(Player.class, area, Player::isAlive)) {
            target.heal(HEAL_AMOUNT);
            serverLevel.sendParticles(ParticleTypes.HEART,
                    target.getX(), target.getY() + 1.0, target.getZ(), 8, 0.4, 0.5, 0.4, 0.05);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 1.5f);

        stack.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return InteractionResult.SUCCESS;
    }
}
