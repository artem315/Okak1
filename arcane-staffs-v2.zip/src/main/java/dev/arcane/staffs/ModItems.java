package dev.arcane.staffs;

import dev.arcane.staffs.item.BlinkStaffItem;
import dev.arcane.staffs.item.FireStaffItem;
import dev.arcane.staffs.item.HealStaffItem;
import dev.arcane.staffs.item.ThunderStaffItem;
import dev.arcane.staffs.item.VortexStaffItem;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import java.util.function.Function;

public final class ModItems {
    public static final Item ARCANE_CRYSTAL = register("arcane_crystal", Item::new,
            new Item.Properties().rarity(Rarity.UNCOMMON));

    public static final Item BLINK_STAFF = register("blink_staff", BlinkStaffItem::new,
            new Item.Properties().durability(500).rarity(Rarity.RARE));

    public static final Item THUNDER_STAFF = register("thunder_staff", ThunderStaffItem::new,
            new Item.Properties().durability(250).rarity(Rarity.EPIC));

    public static final Item FIRE_STAFF = register("fire_staff", FireStaffItem::new,
            new Item.Properties().durability(300).rarity(Rarity.RARE));

    public static final Item HEAL_STAFF = register("heal_staff", HealStaffItem::new,
            new Item.Properties().durability(200).rarity(Rarity.RARE));

    public static final Item VORTEX_STAFF = register("vortex_staff", VortexStaffItem::new,
            new Item.Properties().durability(250).rarity(Rarity.EPIC));

    public static final ResourceKey<CreativeModeTab> TAB_KEY = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
            Identifier.fromNamespaceAndPath(ArcaneStaffs.MOD_ID, "arcane_tab"));

    private ModItems() {}

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(ArcaneStaffs.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_KEY, FabricCreativeModeTab.builder()
                .title(Component.translatable("itemGroup.arcanestaffs"))
                .icon(() -> new ItemStack(THUNDER_STAFF))
                .displayItems((params, output) -> {
                    output.accept(ARCANE_CRYSTAL);
                    output.accept(BLINK_STAFF);
                    output.accept(THUNDER_STAFF);
                    output.accept(FIRE_STAFF);
                    output.accept(HEAL_STAFF);
                    output.accept(VORTEX_STAFF);
                })
                .build());
    }
}
