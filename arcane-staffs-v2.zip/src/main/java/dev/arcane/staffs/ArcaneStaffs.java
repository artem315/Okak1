package dev.arcane.staffs;

import net.fabricmc.api.ModInitializer;

public class ArcaneStaffs implements ModInitializer {
    public static final String MOD_ID = "arcanestaffs";

    @Override
    public void onInitialize() {
        ModItems.init();
    }
}
