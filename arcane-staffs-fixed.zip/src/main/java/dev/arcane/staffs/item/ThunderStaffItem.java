package dev.arcane.staffs.item;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/** ПКМ: молния в точку прицела (до 40 блоков) и цепные удары по 3 ближайшим монстрам. */
public class ThunderStaffItem extends Item {
    private static final double RANGE = 40.0;
    private static final double CHAIN_RADIUS = 6.0;
    private static final int CHAIN_LIMIT = 3;
    private static final int COOLDOWN_TICKS = 40;

    public ThunderStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = player.getItemInHand(hand);
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));

        BlockHitResult hit = level.clip(new ClipContext(
                eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        if (hit.getType() == HitResult.Type.MISS) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0f, 1.0f);
            return InteractionResult.FAIL;
        }

        Vec3 impact = Vec3.atBottomCenterOf(hit.getBlockPos().above());
        strike(serverLevel, serverPlayer, impact);

        List<Monster> chain = serverLevel
                .getEntitiesOfClass(Monster.class, new AABB(hit.getBlockPos()).inflate(CHAIN_RADIUS), Monster::isAlive)
                .stream()
                .sorted(Comparator.comparingDouble(m -> m.distanceToSqr(impact)))
                .limit(CHAIN_LIMIT)
                .toList();
        for (Monster monster : chain) {
            strike(serverLevel, serverPlayer, monster.position());
        }

        player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        stack.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return InteractionResult.SUCCESS;
    }

    private static void strike(ServerLevel level, ServerPlayer owner, Vec3 pos) {
        EntityType<?> type = BuiltInRegistries.ENTITY_TYPE
                .getOptional(Identifier.withDefaultNamespace("lightning_bolt")).orElse(null);
        if (type == null) return;
        Entity entity = type.create(level, EntitySpawnReason.TRIGGERED);
        if (!(entity instanceof LightningBolt bolt)) return;
        bolt.setPos(pos);
        bolt.setCause(owner);
        level.addFreshEntity(bolt);
    }
}
