package dev.arcane.staffs.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** ПКМ: мгновенная телепортация туда, куда смотришь (до 24 блоков), со шлейфом частиц. */
public class BlinkStaffItem extends Item {
    private static final double RANGE = 24.0;
    private static final int COOLDOWN_TICKS = 30;

    public BlinkStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.SUCCESS; // клиент: просто анимация взмаха
        }

        ItemStack stack = player.getItemInHand(hand);
        Vec3 look = player.getLookAngle();
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(look.scale(RANGE));

        BlockHitResult hit = level.clip(new ClipContext(
                eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();

        // Точка для ног: чуть отступаем от препятствия, затем отступаем назад, пока не станет свободно
        Vec3 from = player.position();
        Vec3 feet = aim.subtract(look.scale(0.6)).subtract(0, player.getEyeHeight(), 0);
        Vec3 dest = null;
        for (int i = 0; i < 10; i++) {
            Vec3 candidate = feet.subtract(look.scale(0.5 * i));
            if (level.noCollision(player, player.getBoundingBox().move(candidate.subtract(from)))) {
                dest = candidate;
                break;
            }
        }

        if (dest == null) {
            level.playSound(null, from.x, from.y, from.z, SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 1.0f, 1.0f);
            return InteractionResult.FAIL;
        }

        // Шлейф от старой точки к новой
        double dist = from.distanceTo(dest);
        for (int i = 0; i <= (int) dist; i++) {
            Vec3 p = from.lerp(dest, i / Math.max(dist, 1.0)).add(0, 1.0, 0);
            serverLevel.sendParticles(ParticleTypes.REVERSE_PORTAL, p.x, p.y, p.z, 3, 0.1, 0.1, 0.1, 0.02);
        }
        serverLevel.sendParticles(ParticleTypes.PORTAL, from.x, from.y + 1, from.z, 40, 0.3, 0.6, 0.3, 0.3);
        level.playSound(null, from.x, from.y, from.z, SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS, 1.0f, 1.2f);

        serverPlayer.connection.teleport(dest.x, dest.y, dest.z, player.getYRot(), player.getXRot());
        player.resetFallDistance();

        serverLevel.sendParticles(ParticleTypes.PORTAL, dest.x, dest.y + 1, dest.z, 40, 0.3, 0.6, 0.3, 0.3);
        level.playSound(null, dest.x, dest.y, dest.z, SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS, 1.0f, 0.8f);

        player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        stack.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return InteractionResult.SUCCESS;
    }
}
